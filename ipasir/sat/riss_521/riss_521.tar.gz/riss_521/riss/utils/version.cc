/*
 * This file was created automatically. Do not change it.
 * If you want to distribute the source code without
 * git, make sure you include this file in your bundle.
 */
#include "riss/utils/version.h"

const char* Riss::gitSHA1         = "v5.2.0-118-g8868ec2";
const char* Riss::gitDate         = "Fri Apr 8 00:01:08 2016";
const char* Riss::solverVersion   = "5.2.1";
const char* Riss::signature       = "riss 5.2.1 build v5.2.0-118-g8868ec2";
