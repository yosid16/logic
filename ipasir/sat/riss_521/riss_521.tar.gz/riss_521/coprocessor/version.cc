/*
 * This file was created automatically. Do not change it.
 * If you want to distribute the source code without
 * git, make sure you include this file in your bundle.
 */
#include "coprocessor/version.h"

const char* Coprocessor::gitSHA1            = "v5.2.0-118-g8868ec2";
const char* Coprocessor::gitDate            = "Fri Apr 8 00:01:08 2016";
const char* Coprocessor::coprocessorVersion = "5.2.1";
const char* Coprocessor::signature          = "coprocessor 5.2.1 build v5.2.0-118-g8868ec2";
