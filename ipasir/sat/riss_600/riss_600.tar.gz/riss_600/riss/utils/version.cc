/*
 * This file was created automatically. Do not change it.
 * If you want to distribute the source code without
 * git, make sure you include this file in your bundle.
 */
#include "riss/utils/version.h"

const char* Riss::gitSHA1         = "v6.0";
const char* Riss::gitDate         = "Sat Apr 16 21:38:29 2016";
const char* Riss::solverVersion   = "6.0.0";
const char* Riss::signature       = "riss 6.0.0 build v6.0";
